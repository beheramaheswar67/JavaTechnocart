package services;
import model.Employee;
import repository.DBConnect;
import java.sql.*;


public class EmployeeService {
    public Employee createEmployee(Employee employee){
        String sql = "INSERT INTO employee (fullname, gender, department, job_title, salary, mobile, email)"
                + "VALUES ('%s', '%s', '%s', '%s', %f, '%s', '%s')";
        
        String formmatedSql = sql.formatted(employee.getFullName(), employee.getGender(), employee.getDepartment(), employee.getJobTitle(),
        employee.getSalary(),employee.getMobileNo(),employee.getEmail());
            
        try{
            Statement statement=DBConnect.getConnection().createStatement();
            statement.executeUpdate(formmatedSql);
            
            return employee;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;    
    }
    
    public Employee updateEmployee(Employee employee){
        String sql = "UPDATE employee SET fullname='%s',gender='%s',department='%s',job_title='%s',salary=%f,mobile='%s',email='%s'WHERE id=%d";
            
        String formmatedSql = sql.formatted(employee.getFullName(),employee.getGender(), employee.getDepartment(), employee.getJobTitle(), employee.getSalary(), 
                employee.getMobileNo(), employee.getEmail(), employee.getID());
        
        try{
            Statement statement=DBConnect.getConnection().createStatement();
            statement.executeUpdate(formmatedSql);
            
            return employee;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null; 
    }
    
    public ResultSet getEmployees(){
        String sql="SELECT * FROM employee";
        try{
            Statement s=DBConnect.getConnection().createStatement();
            ResultSet resultSet=s.executeQuery(sql);
            return resultSet;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public Employee deleteEmployee(Employee employee){
        String sql = String.format("DELETE FROM employee WHERE id = %d",employee.getID());
        try{
            Statement s=DBConnect.getConnection().createStatement();
            s.executeUpdate(sql);
            return employee;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;     
    }
   
    
}
