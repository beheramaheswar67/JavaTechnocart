/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {

    private static final String URL = "jdbc:mysql://localhost:3306/jt_core";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Mahesh@123";

    private DBConnect() {
    }

    public static Connection getConnection() {
        try {
            Connection c = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Database connection successfully established.");
            return c;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Database connection failed.");
        }
        return null;
    }
}