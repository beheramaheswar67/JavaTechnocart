
package model;

public class Employee {
    private int ID;
    private String FullName;
    private String Gender;
    private String Department;
    private String JobTitle;
    private double Salary;
    private String MobileNo;
    private String Email;

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public void setJobTitle(String JobTitle) {
        this.JobTitle = JobTitle;
    }

    public void setSalary(double Salary) {
        this.Salary = Salary;
    }

    public void setMobileNo(String MobileNo) {
        this.MobileNo = MobileNo;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    
    
    public int getID() {
        return ID;
    }

    public String getFullName() {
        return FullName;
    }

    public String getGender() {
        return Gender;
    }

    public String getDepartment() {
        return Department;
    }

    public String getJobTitle() {
        return JobTitle;
    }

    public double getSalary() {
        return Salary;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public String getEmail() {
        return Email;
    }

    public Employee() {
    }

    public Employee(int ID, String FullName, String Gender, String Department, String JobTitle, double Salary, String MobileNo, String Email) {
        this.ID = ID;
        this.FullName = FullName;
        this.Gender = Gender;
        this.Department = Department;
        this.JobTitle = JobTitle;
        this.Salary = Salary;
        this.MobileNo = MobileNo;
        this.Email = Email;
    }
    
    
    
    
    
    
    
    
}
